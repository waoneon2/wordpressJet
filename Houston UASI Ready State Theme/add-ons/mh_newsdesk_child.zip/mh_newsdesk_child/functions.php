<?php

/***** Load Stylesheets *****/

function mh_newsdesk_child_styles() {
    wp_enqueue_style('mh-newsdesk-parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('mh-newsdesk-child-style', get_stylesheet_directory_uri() . '/style.css', array('mh-newsdesk-parent-style'));
}
add_action('wp_enqueue_scripts', 'mh_newsdesk_child_styles');